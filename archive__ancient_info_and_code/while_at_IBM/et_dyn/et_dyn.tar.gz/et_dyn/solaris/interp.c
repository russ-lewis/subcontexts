const char __invoke_dynamic_linker__[] __attribute__ ((section (".interp"))) = "/usr/lib/ld.so.1";
